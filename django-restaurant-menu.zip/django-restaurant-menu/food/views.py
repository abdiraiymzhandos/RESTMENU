from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Item, Category
from .forms import ItemForm
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.mixins import UserPassesTestMixin
from django.utils.decorators import method_decorator


def index(request):
    selected_category = request.GET.get('category')
    categories = Category.objects.all().order_by('order')

    if selected_category:
        items = Item.objects.filter(
            category_id=selected_category).select_related(
                'category').order_by('category__order', 'pk')
    else:
        items = Item.objects.all().select_related(
            'category').order_by('category__order', 'pk')

    context = {
        'categories': categories,
        'item_list': items,
        'selected_category': selected_category,
    }
    return render(request, 'food/index.html', context)


class IndexClassView(ListView):
    model = Item
    template_name = 'food/index.html'
    context_object_name = 'item_list'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['categories'] = Category.objects.all().order_by('order')
        context['selected_category'] = self.request.GET.get('category', None)
        return context

    def get_queryset(self):
        selected_category = self.request.GET.get('category', None)
        if selected_category:
            return Item.objects.filter(category__id=selected_category).order_by('category__order', 'pk')
        return Item.objects.all().order_by('category__order', 'pk')


def item(request):
    return HttpResponse('<h1>This is an item view</h1>')


def detail(request,item_id):
    item = Item.objects.get(pk=item_id)

    context = {
        'item' : item,
    }

    return render(request, 'food/detail.html', context)


class FoodDetail(DetailView):
    model = Item
    template_name = 'food/detail.html'


class CreateItem(UserPassesTestMixin, CreateView):
    model = Item
    form_class = ItemForm
    template_name = 'food/item-form.html'

    def form_valid(self, form):
        form.instance.user_name = self.request.user
        return super().form_valid(form)

    def test_func(self):
        return self.request.user.is_superuser


class UpdateItem(UserPassesTestMixin, UpdateView):
    model = Item
    form_class = ItemForm
    template_name = 'food/item-form.html'

    def test_func(self):
        return self.request.user.is_superuser


class DeleteItem(UserPassesTestMixin, DeleteView):
    model = Item
    template_name = 'food/item-delete.html'
    success_url = '/'

    def test_func(self):
        return self.request.user.is_superuser


@user_passes_test(lambda u: u.is_superuser)
def create_item(request):
    form = ItemForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('food:index')
    return render(request, 'food/item-form.html', {'form': form})


@user_passes_test(lambda u: u.is_superuser)
def update_item(request, id):
    item = Item.objects.get(id=id)
    form = ItemForm(request.POST or None, instance=item)
    if form.is_valid():
        form.save()
        return redirect('food:index')
    return render(request, 'food/item-form.html', {'form': form, 'item': item})


@user_passes_test(lambda u: u.is_superuser)
def delete_item(request, id):
    item = Item.objects.get(id=id)
    if request.method == 'POST':
        item.delete()
        return redirect('food:index')
    return render(request, 'food/item-delete.html', {'item': item})
