# django-restaurant-menu
A Django app for creating a restaurant's online menu. Authenticated users can add, edit, and delete menu items. The app will also log which user created an item.

##Screenshots
Here are a few images of the app running locally with sample products added:
![image](https://github.com/spryan27/django-restaurant-menu/assets/7785384/f6e50289-6053-4e52-baaf-b056742877bd)
![image](https://github.com/spryan27/django-restaurant-menu/assets/7785384/a50294a7-0c43-4716-a7a9-500c6874fc83)


